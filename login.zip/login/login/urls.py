"""login URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from myapp.views import *
from django.urls import path,include 
from django.conf.urls.static import static
from django.conf import settings
from rest_framework_simplejwt.views import TokenObtainPairView,TokenRefreshView
from usersauth import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('register/', Register.as_view(), name='register'),
    path('login/', Login.as_view(), name='login'),
    path('', login_render.as_view(), name='loginrender'),
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),   
    path('profile/', ProfileApiView.as_view(), name='profile'),   
    path('profilecard/', profilecardapi.as_view(), name='profilecard'),   
    path('friendrequest/', FriendRequestApi.as_view(), name='friendrequest'),
    path('accept_delete/<str:operation>/', AcceptOrDeleteApi.as_view(), name='accept_delete'),
    path('follow-user/',followApi.as_view(),name='follow-user'),
    path('unfollow/',unfollowApiview.as_view(),name='unfollow'),
    path('removefollower/<int:follower_i_am_removing_id>/',removeFollowerview.as_view(),name='removefollower'),
    path('removefriend/',removeFriendView.as_view(),name='removefriend'),
    path('createpost/',CreatePostApi.as_view(),name='Createpost'),
    path('comment/',CommentApi.as_view(),name='comment'),
    path('recomment/',RecommentApi.as_view(),name='recomment'),
    path('conversation/',ConversationApi.as_view(),name='conversation'),
    path('checknotification/',CheckNotification.as_view(),name='checknotification'),
    path('feeds/',FeedsApi.as_view(),name='feeds'),




    path('profileRender/',profileRender,name = 'profileRender'),
    path('onboardrender/',onboardrender,name = 'onboardrender'),
    path('userlist/',Userlist,name = 'userlist'),
    path('notifications/',notificationlist,name = 'notifications'),
    path('friendrequests/',friendrequestrender,name = 'friendrequests'),
    path('createpostrender/',createpostrender,name = 'createpostrender'),
    path('ShowAllPosts/',ShowAllPosts,name = 'ShowAllPosts'),
    path('chats/',chatpagerender,name = 'chatpagerender'),
    path('social/',include('usersauth.urls'))


    



]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)
    # urlpatterns += static(settings.STATIC_URL,document_root = settings.STATIC_ROOT)