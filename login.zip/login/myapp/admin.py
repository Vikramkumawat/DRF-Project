from django.contrib import admin
from .models import *
from django.contrib.auth.models import Group


admin.site.unregister(Group)

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ['id','user','Bio']
    list_display_links = ['user']
    search_fields = ['user__username']
    list_filter = ['followers','following','Bio','user']

    
@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ['id','Description']
    list_display_links = ['Description']
    search_fields = ['id','Description']
    list_filter = ['Description']

@admin.register(Follower)
class FollowerAdmin(admin.ModelAdmin):
    list_display = ['id','user']
    list_display_links = ['user']
    search_fields = ['user__username','id']
    list_filter = ['user']

@admin.register(Following)
class FollowingAdmin(admin.ModelAdmin):
    list_display = ['id','user']
    list_display_links = ['user']
    search_fields = ['user__username','id']
    list_filter = ['user']


@admin.register(Friend)
class FriendAdmin(admin.ModelAdmin):
    list_display = ['id','user']
    list_display_links = ['user']
    search_fields = ['user__username','id']
    list_filter = ['user']


@admin.register(FriendRequest)
class FriendRequestAdmin(admin.ModelAdmin):
    list_display = ['id','sender','reciever']
    list_display_links = ['sender','reciever']
    search_fields = ['sender__username','reciever__username','id']
    list_filter = ['sender','reciever']

@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ['id','commentor','comment']
    list_display_links = ['comment','commentor']
    search_fields = ['commentor__username','id']
    

@admin.register(ReComment)
class ReCommentAdmin(admin.ModelAdmin):
    list_display = ['id','commentor',"commentreply"]
    list_display_links = ['commentreply','commentor']
    search_fields = ['commentor__username','id']
    

@admin.register(Messege)
class MessegeAdmin(admin.ModelAdmin):
    list_display = ['id',"sender","reciever","messege_time"]
    list_display_links = ['sender','reciever']
    search_fields = ['sender__username','reciever__username','id']
    list_filter = ['messege_time']

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ['id','reciever','details','notification_time']
    list_display_links = ['reciever']
    search_fields = ['reciever__username']
    list_filter = ['reciever']

