from .models import Notification
from django.contrib.auth.models import User

def send_notification(reciever,messege):
    notification_sent = Notification.objects.create(reciever = reciever,details = messege)
    return notification_sent