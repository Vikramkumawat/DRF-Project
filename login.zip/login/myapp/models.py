from django.db import models
from django.contrib.auth.models import User


class ReComment(models.Model):
    commentreply = models.CharField(max_length = 300)
    commentor = models.ForeignKey(User,on_delete = models.CASCADE,default = 1)

    def __str__(self):
        return self.commentreply if self.commentreply else None

    class Meta:
        ordering = ['commentor']
        verbose_name = 'Comment Reply'
        verbose_name_plural = 'Comment Replies'
    
class Comment(models.Model):
    comment = models.CharField(max_length = 300)
    recomments = models.ManyToManyField(ReComment, related_name = "recomment",null = True,blank=True)
    commentor = models.ForeignKey(User,on_delete = models.CASCADE)

    def __str__(self):
        return self.comment if self.comment else None

    class Meta:
        ordering = ['id','commentor__username','comment']
        verbose_name = 'Comment'
        verbose_name_plural = 'Comments List'

class Post(models.Model):
    Image = models.ImageField(upload_to='images/',null=True)
    Description = models.CharField(max_length=200,null = True,blank = True)
    comments = models.ManyToManyField(Comment,related_name = "mycomment",null = True)

    def __str__(self):
        return self.Description if self.Description else " "

    class Meta:
        ordering = ['Description']
        verbose_name = 'Post'
        verbose_name_plural = 'Posts List'

class Follower(models.Model):
    user = models.ForeignKey(User,on_delete = models.CASCADE)

    def __str__(self):
        return self.user.username

    class Meta:
        verbose_name = 'Follower'
        verbose_name_plural = 'Followers List'

class Following(models.Model):
    user = models.ForeignKey(User,on_delete = models.CASCADE)

    def __str__(self):
        return self.user.username

    class Meta:
        verbose_name_plural = 'Following List'

class Friend(models.Model):
    user = models.ForeignKey(User, on_delete = models.CASCADE)

    def __str__(self):
        return self.user.username

    class Meta:
        verbose_name_plural = 'Friend List'

class FriendRequest(models.Model):
    sender = models.ForeignKey(User,related_name = 'sender1',on_delete = models.CASCADE)
    reciever = models.ForeignKey(User, on_delete = models.CASCADE)

    def __str__(self):
        return self.sender.username

    class Meta:
        verbose_name_plural = 'Friend Request list'

class Profile(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    display_picture = models.ImageField(upload_to = 'images/',null = True)
    followers = models.ManyToManyField(Follower,related_name = 'followerRelation',null = True)
    following = models.ManyToManyField(Following, related_name = 'followingRelation',null = True)
    friends = models.ManyToManyField(Friend, related_name = 'friendsRelation',null = True)
    posts = models.ManyToManyField(Post, related_name = 'postRelation',null = True)
    Bio = models.CharField(max_length=100)
    friendrequests = models.ManyToManyField(FriendRequest, related_name = 'friendrequestRelation',null = True)

    def __str__(self):
        return self.user.username

    class Meta:
        verbose_name_plural = 'Profiles'

class Messege(models.Model):
    sender = models.ForeignKey(User,on_delete = models.CASCADE,related_name = "sender")
    reciever = models.ForeignKey(User,on_delete = models.CASCADE, related_name = "reciever")
    messege = models.CharField(max_length = 200)
    messege_time = models.DateTimeField(auto_now_add = True)
    is_read = models.BooleanField(default = False)
    delete_for_me = models.BooleanField(default = False)

    def __str__(self):
        return self.sender.username

    class Meta:
        ordering = ('messege_time',)
        verbose_name_plural = 'Messages'

class Notification(models.Model):
    reciever = models.ForeignKey(User,on_delete =models.CASCADE)
    details = models.CharField(max_length = 200)
    notification_time = models.DateTimeField(auto_now_add = True)

    def __str__(self):
        return self.reciever.username
    
    class Meta:
        ordering = ['notification_time']
        verbose_name_plural = 'Notifications'

