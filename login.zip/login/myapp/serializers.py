from rest_framework import serializers
from django.contrib.auth.models import User
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from .models import *


class UserSerializer(serializers.ModelSerializer):
     class Meta:
        model = User
        fields = ['id', 'username', 'email']


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(max_length=68, min_length=6, write_only=True)
    class Meta:
        model = User
        fields = [ 'id','username','first_name','last_name', 'email','password']


    def validate(self, attrs):
        email = attrs.get('email', '')
        username = attrs.get('username', '')
        if not username.isalnum():
            raise serializers.ValidationError(
                self.default_error_messages)
        return attrs
    def create(self, validated_data):
        return User.objects.create_user(**validated_data)


class CustomToken(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token['username'] = user.username
        token['password']=user.password
        user.refresh_token = str(token)
        user.save() 
        return {
            'refresh': str(token),
            'access': str(token.access_token),
        }



class FollowerSerializer(serializers.ModelSerializer):
    user = serializers.SerializerMethodField('get_followers')

    def get_followers(self,obj):
        return obj.user.username

    class Meta:
        model = Follower
        fields = ('id','user',)


class FollowingSerializer(serializers.ModelSerializer):
    user = serializers.SerializerMethodField('get_followings')

    def get_followings(self,obj):
        return obj.user.username

    class Meta :
        model = Following
        fields = ("id",'user',)


class FriendSerializer(serializers.ModelSerializer):
    user = serializers.SerializerMethodField('get_friends')

    def get_friends(self,obj):
        return obj.user.username

    class Meta :
        model = Following
        fields = ('id','user',)


class FriendRequestSerializer(serializers.ModelSerializer):
    sender = serializers.SerializerMethodField('get_sender')
    display_picture = serializers.SerializerMethodField()
    followers = serializers.SerializerMethodField()
    following = serializers.SerializerMethodField()
    friends = serializers.SerializerMethodField()
    def get_sender(self,obj):
        return obj.sender.username

    def get_display_picture(self,obj):
        return obj.friendrequestRelation.all().get().display_picture.url

    def get_followers(self,obj):
        return obj.friendrequestRelation.get().followers.count()

    def get_following(self,obj):
        return obj.friendrequestRelation.get().following.count()

    def get_friends(self,obj):
        return obj.friendrequestRelation.get().friends.count()


    class Meta:
        model = FriendRequest
        fields = ('id','sender', 'display_picture','followers','following','friends')



class ReCommentSerializer(serializers.ModelSerializer):
    commentor = serializers.SerializerMethodField('get_commentor')

    def get_commentor(self,obj):
        return obj.commentor.username

    class Meta:
        model = ReComment
        fields = ['id','commentreply','commentor',]
    
    def create(self, validated_data):
        return ReComment.objects.create(**validated_data)

class CommentSerializer(serializers.ModelSerializer):
    
    recomments = ReCommentSerializer(many =True,read_only = True)
    commentor = serializers.SerializerMethodField('get_commentor')

    def get_commentor(self,obj):
        return obj.commentor.username

    class Meta:
        model = Comment
        fields = ('id','comment','commentor','recomments',)

    def create(self, validated_data):
        return Comment.objects.create(**validated_data)

class PostSerializer(serializers.ModelSerializer):
    comments = CommentSerializer(many = True,read_only = True)

    class Meta:
        model = Post
        fields = ('id','Image','Description','comments',)



class ProfileEditSerializer(serializers.ModelSerializer):
    user = serializers.SerializerMethodField("get_user")
    # posts = PostSerializer(many = True,read_only = True)
    class Meta:
        model =Profile
        fields = [ 'id','user','display_picture','Bio']

    def get_user(self,obj):
        return obj.user.username

    def create(self,validated_data):
        return Profile.objects.create(**validated_data)

class Frendrqst(serializers.ModelSerializer):
    sender = serializers.SerializerMethodField()
    reciever = serializers.SerializerMethodField()
    def get_sender(self,obj):
        return obj.sender.username
    
    def get_reciever(self,obj):
        return obj.reciever.username

    class Meta:
        model = FriendRequest
        fields = ['id','sender','reciever']

class ProfileSerializer(serializers.ModelSerializer):
    followers = FollowerSerializer(many = True, read_only = True)
    user = serializers.SerializerMethodField('get_username')
    following = FollowingSerializer(many = True,read_only = True)
    friends = FriendSerializer(many = True,read_only = True)
    posts = PostSerializer(many = True,read_only =True)
    friendrequests = Frendrqst(many = True, read_only = True)
    
    def get_username(self,obj):
        return obj.user.username

    class Meta:
        model = Profile
        fields = ['id','user','display_picture','Bio','followers','following','friends','posts','friendrequests']

    
class MessegeSerializer(serializers.ModelSerializer):
    sender = serializers.SerializerMethodField('get_sender')
    reciever = serializers.SerializerMethodField('get_reciever')

    class Meta:
        model = Messege
        fields = ['id','sender','reciever','messege','messege_time']

    def get_sender(self, obj):
        return obj.sender.username

    def get_reciever(self, obj):
        return obj.reciever.username

    def create(self, validated_data):
        return Messege.objects.create(**validated_data)
    

class NotificationSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Notification
        fields = ['id','details','notification_time']


