from rest_framework import status,generics, permissions
from rest_framework.response import Response
from .serializers import *
from django.contrib.auth import login,authenticate
from rest_framework.authtoken.serializers import AuthTokenSerializer
from django.core.mail import send_mail
from rest_framework.renderers import TemplateHTMLRenderer
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth.models import User
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.http import JsonResponse
from rest_framework.decorators import permission_classes,authentication_classes
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser
from .helpers import send_notification
from .models import *
from rest_framework.views import APIView
from rest_framework.decorators import api_view


class Register(APIView):
    permission_classes = (permissions.AllowAny,)
    serializer_class = RegisterSerializer
    def post(self,request): 
        try:
            serializer = self.serializer_class(data=request.data)
            if serializer.is_valid(raise_exception=True):
                user=serializer.save()
                return Response({
                "Success":"Register Successfully",
                }) 
            return Response({
                "Fail":"fill all details in a right way..."
                })    
        except Exception as e:
            return Response({"error":str(e)})         

class login_render(APIView):
    permission_classes = (permissions.AllowAny,)
    renderer_classes = [TemplateHTMLRenderer]
    template_name = "home.html"
    def get(self,request):
        serializer = AuthTokenSerializer()
        return Response({"sea":0})

class Login(APIView):
    permission_classes = (permissions.AllowAny,)
    serializer_class=CustomToken

    def post(self,request):
        try:
            username=request.data.get('username')
            password=request.data.get('password')
            user=authenticate(username = username,password=password)
            if user is not None:
                serializer = AuthTokenSerializer(data=request.data)
                if serializer.is_valid(raise_exception=True):
                
                    if user is not None:
                        login(request, user)
                        customtoken=CustomToken.get_token(user)
                        return  Response(customtoken)   
                    else:  
                        return Response(serializer.data,{"error":"You are not loged in"})
                return Response({'error':"Invalid Input...."})
            else:
                return Response({"error":"incorrrect credentials !"})
        except Exception as e:
            return Response({"error":str(e)})




def profileRender(request):
    if request.method == "GET":
        return render(request,"userprofile.html")

def onboardrender(request):
    return render(request,'onboarding.html')


class ProfileApiView(APIView):
    authentication_classes = [JWTAuthentication] 
    permission_classes = (IsAuthenticated,)
    serializer_class = ProfileEditSerializer
    
    def get(self,request):
        try:
            user = request.user
            user = User.objects.get(username = user)
            serializer = self.serializer_class(Profile.objects.get(user = user.id))
            if serializer.data is None:
                return Response({"error":"create Profile First"})
            return JsonResponse(serializer.data,
                        safe=False, 
                        status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error":"create a profile first..."})

    def post(self, request): 
        try:
            if not Profile.objects.filter(user = request.user).exists():
                data = request.data.dict()
                data['user'] = request.user
                serializer = self.serializer_class(data = data,partial = True)

                if serializer.is_valid():
                    serializer.save(user = request.user)
                    return Response({"success":"Profile Created succesfully","data":serializer.data},status = status.HTTP_200_OK)

                return Response(serializer.data)
                return Response({"Fail":"kripya sahi data add kre"})
            else:
                return Response({"ha ha ha...":"user already exists..."})
        except Exception as e:
            return Response({"error":str(e)})

   

class profilecardapi(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = (IsAuthenticated,)
    serializer_class = ProfileSerializer

    def get(self,request):        
        try:
            serializer = self.serializer_class(Profile.objects.exclude(user = request.user.id),many = True)
            return JsonResponse(serializer.data,
                            safe=False, 
                            status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error":str(e)})

class FriendRequestApi(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = (IsAuthenticated,)
    
    def get(self,request):
        try:
            friendrequests = FriendRequest.objects.filter(reciever =request.user)
            if friendrequests.exists():
                serializer = FriendRequestSerializer(friendrequests,many = True) 
                return Response(serializer.data)
            else:
                return Response({'error':"You Don't have any friend request..."})
        except Exception as e:
            return Response({"error":str(e)})

    def post(self,request):
        try:
            reciever_id = request.POST.get('id')
            reciever_id = int(reciever_id)
            sender_profile = Profile.objects.get(user= request.user)
            profile = Profile.objects.get(id = reciever_id)
            if not sender_profile.friends.filter(user = profile.user).exists():
                if not FriendRequest.objects.filter(sender = sender_profile.user,reciever = profile.user).exists():
                    send_request = FriendRequest.objects.create(sender = sender_profile.user,reciever = profile.user)
                    profile.friendrequests.add(send_request)
                    send_notification(reciever = profile.user, messege = sender_profile.user.username+" sent you a friend request...")
                    return Response({"success":"Request sent..."})
                else:
                    return Response({"error":"You have alreday sent a request to this user..."})
            else:
                return Response({"error":"You are already friends"})
        except Exception as e:
            return Response({"error":str(e)})

    def delete(self,request):
        try:
            reciever_id = request.POST.get('reciever_id')
            reciever = Profile.objects.get(id = reciever_id)
            if FriendRequest.objects.filter(sender = request.user,reciever= reciever.user).exists():
                friendrequest = FriendRequest.objects.get(sender = request.user,reciever= reciever.user)
                friendrequest.delete()
                return Response({"success":"request cencled..."})
            else:
                return Response({'error':'request already deleted'})
        except Exception as e:
            return Response({"error":str(e)})




class AcceptOrDeleteApi(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = (IsAuthenticated,)


    def post(self,request,operation):
        try:
            sender = request.POST.get('sender')
            sender_profile = Profile.objects.get(user__username = sender)
            reciever_profile = Profile.objects.get(user = request.user)
            friend_req_obj = FriendRequest.objects.get(sender = sender_profile.user, reciever = request.user)
            if operation == 'add':
                if not Friend.objects.filter(user =sender_profile.user).exists():
                    friend1 = Friend.objects.create(user = sender_profile.user)
                else:
                    friend1 = Friend.objects.get(user = sender_profile.user)
                if not Friend.objects.filter(user =reciever_profile.user).exists():
                    friend2 = Friend.objects.create(user = reciever_profile.user)
                else:
                    friend2 = Friend.objects.get(user = reciever_profile.user)
                reciever_profile.friends.add(friend1)
                sender_profile.friends.add(friend2)
                send_notification(reciever = sender_profile.user, messege = reciever_profile.user.username+" has accepted your friend request...")
                friend_req_obj.delete()
                return Response({"success":"Now You Both are Friends..."})

            elif operation == 'remove':
                friend_req_obj.delete() 
                return Response({"success":"Request is now deleted..."})

            else:
                return Response({"error":"Don't play with url"})
        except Exception as e:
            return Response({"error":str(e)})


class followApi(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = (IsAuthenticated,)

    def post(self,request):
        try:
            new_follow_profile_id = request.POST.get('id')
            new_follow_profile = Profile.objects.get(id = new_follow_profile_id)
            follower_profile = Profile.objects.get(user = request.user.id)
            if not Follower.objects.filter(user = follower_profile.user).exists():
                followerObj = Follower.objects.create(user = follower_profile.user)
            else:
                followerObj = Follower.objects.get(user = follower_profile.user)
            if not Following.objects.filter(user = new_follow_profile.user):
                newFollowObj = Following.objects.create(user = new_follow_profile.user)
            else:
                newFollowObj = Following.objects.get(user = new_follow_profile.user)
            if  newFollowObj not in follower_profile.following.all():              
                added_in_my_follower = new_follow_profile.followers.add(followerObj)
                added_in_new_user_following = follower_profile.following.add(newFollowObj)
                send_notification(reciever = new_follow_profile.user, messege = follower_profile.user.username+" followed you")
                return Response({"success":"Follow Successfull..."})
            else:
                return Response({"error":"you already followed..."})
        except Exception as e:
            return Response({"error":str(e)})


class unfollowApiview(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = (IsAuthenticated,)

    def post(self,request):
        try:
            user_i_am_unfollowing_id = request.POST.get('id')
            user_i_am_unfollowing_id = int(user_i_am_unfollowing_id)
            user_i_am_unfollowing = Profile.objects.get(id = user_i_am_unfollowing_id)
            follower_user_profile = Profile.objects.get(user = request.user)
            

            followerObj = Follower.objects.get(user = request.user)
            i_am_following_obj = Following.objects.get(user = user_i_am_unfollowing.user)
            user_i_am_unfollowing.followers.remove(followerObj)
            follower_user_profile.following.remove(i_am_following_obj)
            check_relation_obj = followerObj.followerRelation.all()
            if not check_relation_obj.exists():
                followerObj.delete()
            check_relation_obj = i_am_following_obj.followingRelation.all()
            if not check_relation_obj.exists():
                i_am_following_obj.delete()
            return Response({"success":"unfolloewd user..."})
        
        except Exception as e:
            return Response({"error":str(e)})

class removeFollowerview(generics.GenericAPIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = (IsAuthenticated,)

    def post(self,request,follower_i_am_removing_id):
        try:
            follower_i_am_removing_profile = Profile.objects.get(id = follower_i_am_removing_id)
            user_logged_in_profile = Profile.objects.get(user = request.user)

            follower_obj = Follower.objects.get(user = follower_i_am_removing_profile.user )
            following_obj = Following.objects.get(user = request.user)
            follower_i_am_removing_profile.following.remove(following_obj)
            user_logged_in_profile.followers.remove(follower_obj)
            if not follower_obj.followerRelation.all().exists():
                follower_obj.delete()
            if not following_obj.followingRelation.all().exists():
                following_obj.delete()
            return Response({"OK":"follower removed..."})
        except Exception as e:
            return Response({"unexpected error":str(e)})


class removeFriendView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes =(IsAuthenticated,)

    def post(self,request):
        try:
            friend_i_am_removing_id = request.POST.get('id')
            friend_i_am_removing_id = int(friend_i_am_removing_id)
            friend_i_am_removing_profile = Profile.objects.get(id = friend_i_am_removing_id)
            friendObj1 = Friend.objects.get(user = request.user)
            friendObj2 = Friend.objects.get(user = friend_i_am_removing_profile.user)
            user_logged_in_profile = Profile.objects.get(user = request.user)
            friend_i_am_removing_profile.friends.remove(friendObj1)
            user_logged_in_profile.friends.remove(friendObj2)
            if not friendObj1.friendsRelation.all().exists():
                friendObj1.delete()
            if not friendObj2.friendsRelation.all().exists():
                friendObj2.delete()
            return Response({"success":'Friend is removed...'})
        except Exception as e:
            return Response({"errorrror":str(e)})


class CreatePostApi(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = (IsAuthenticated,)
    serializer_class = PostSerializer

    def post(self, request):
        try:
            serializer = self.serializer_class(data = request.data)
            if serializer.is_valid():
                post = serializer.save()
                user_profile = Profile.objects.get(user=request.user)
                user_profile.posts.add(post)
                return Response({"success":"Post saved"})
            else:
                return Response({"error":"Please enter valid data"})
        except Exception as e:
            return Response({"error": str(e)})
    
    def delete(self,request):
        try:
            post_id = request.POST.get("post_id")
            
            post = Post.objects.get(id = post_id)
            if post.postRelation.filter(user = request.user).exists():
                post.delete()
                return Response({"success":"deleted"})
            else:
                return Response({"error":"This Post does not belongs to you"})
        except Exception as e:
            return Response({"error": str(e)})
    

class CommentApi(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = (IsAuthenticated,)
    serializer_class = CommentSerializer

    def post(self,request):
        try:
            post_id = request.POST.get("post_id")
            post = Post.objects.get(id = post_id)
            data = request.data.dict()
            data['commentor'] = request.user.id
            del data['post_id']
            serializer = self.serializer_class(data = data)
            if serializer.is_valid():
                post_comment_obj = serializer.save(commentor = request.user)
                post.comments.add(post_comment_obj)

                return Response({"success":"Comment Added!"})

            return Response({"error":str(serializer.error)})
        except Exception as e:
            return Response({"error":str(e)})

    def put(self,request):
        try:
            comment_id = request.POST.get("comment_id")
            comment_id = int(comment_id)
            comment = Comment.objects.get(id = comment_id)
            if comment is not None:
                serializer = self.serializer_class(comment , data = request.data,partial = True)
                if serializer.is_valid():
                    serializer.save()
                    return Response({"success":"Comment edited..."})
                return Response({"error":"Enter valid data"})
            
            return Response({"error":"Comment does not exist..."})
        except Exception as e:
            return Response({"error":str(e)})


class RecommentApi(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    
    def post(self,request,):
        try:
            comment_id = request.POST.get("comment_id")
            comment_id = int(comment_id)
            comment = Comment.objects.get(id = comment_id)
            data = request.data.dict()
            data['commentor'] = request.user.id
            del data['comment_id']
            serializer = ReCommentSerializer(data = data)
            if serializer.is_valid():
                commentObj = serializer.save(commentor = request.user)
                comment.recomments.add(commentObj)
                return Response({"Done":"Replied the comment..."})
            return Response({"Error":str(serializer.error)})
        except Exception as e:
            return Response({"Error":str(e)})

    

    def put(self,request):
        try:
            recomment_id = request.POST.get("recomment_id")
            recomment = ReComment.objects.get(id = recomment_id)
            if recomment is not None:
                serializer = ReCommentSerializer(recomment , data = request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response({"Done":"Comment edited..."})
                return Response({"Error":"Enter valid data"})
            
            return Response({"Error":"Comment does not exist..."})
        except Exception as e:
            return Response({"Error":str(e)})


class ConversationApi(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            reciever_id = request.query_params.get('reciever_id')
            reciever = Profile.objects.get(id = reciever_id)
            messeges = Messege.objects.filter(sender = request.user , reciever = reciever.user,delete_for_me = False) | Messege.objects.filter(sender = reciever.user , reciever = request.user)
            serializer = MessegeSerializer(messeges,many = True)
            return Response(serializer.data)
        except Exception as e:
            return Response({"error":str(e)})


    def post(self, request):
        try:
            reciever_id = request.POST.get("reciever_id")
            
            data = request.data.dict()
            data['sender'] = request.user.id
            data['reciever'] = reciever_id
            reciever = Profile.objects.get(id = reciever_id)
            serializer = MessegeSerializer(data = data)
            if serializer.is_valid():
                serializer.save(sender = request.user,reciever = reciever.user)
                send_notification(reciever = reciever.user, messege = request.user.username+" sent you a messege...")
                return Response({"success":serializer.data})
            return Response({"error":"invalid input..."})
        except Exception as e:
            return Response({"error":str(e)})

    
    def put(self,request):
        try:
            
            msg_id = request.GET.get('id')
            msg_id = int(msg_id)
            messege = Messege.objects.get(id = msg_id)
            if messege is not None:
                data = {'delete_for_me': True}
                messege.delete_for_me = True
                messege.save()
                
                return Response({"success":"messege deleted for you"})
                
            return ({"error":"messege not deleted"})
        except Exception as e:
            return Response({"error":str(e)})

    def delete(self,request):
        try:

            messege_id = request.GET.get("id")
            messege = Messege.objects.get(id = messege_id)
            messege.delete()
            return Response({"success":"messege deleted for everyone..."})
        except Exception as e:
            return Response({"error":str(e)}) 
        


class CheckNotification(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self,request):
        try :
            notification = Notification.objects.filter(reciever = request.user)
            if notification.exists():
                serializer = NotificationSerializer(notification,many = True)
                return Response(serializer.data)
            return Response({"error":"You Dont have any notification"})
        except Exception as e:
            return Response({"error":str(e)})

    def delete(self,request):
        try:
            notification_id = request.POST.get("id")
            notification = Notification.objects.get(id = notification_id)
            notification.delete()
            return Response({"success":"Notification deleted..."})
        except Exception as e:
            return Response({"error":str(e)})


class FeedsApi(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self,request):
        try:
            posts = Post.objects.all()
            serializer = PostSerializer(posts,many = True)
            return Response(serializer.data)
        except Exception as e:
            return Response({"error":str(e)})


def Userlist(request):
    return render(request,'profilelist.html')

def notificationlist(request):
    return render(request,'notifications.html')

def friendrequestrender(request):
    return render(request,'friendrequestpage.html')

def createpostrender(request):
    return render(request,'createpostpage.html')

def ShowAllPosts(request):
    return render(request,'newsfeed.html')

def chatpagerender(request):
    return render(request,'chatprofilespage.html')

