$('#user_profile').ready(function (event) {
    $.ajax({
        url: '/feeds/',
        headers: {
            'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
        },
        type: "GET",
        tokenFlag: true,
        success: function (data) {
            console.log(data)
            if (!data['error']) {
                for (let post_number = 0; post_number < data.length; post_number++) {
                    var commentnumber = data[post_number].comments.length
                    $('.postappend').append(

                        `<div class="col-md-12 col-lg-12 card mt-5 postclass">
              <article class="post vt-post innerpost">
                  <div class="row">
                      <div class="col-xs-12 col-sm-5 col-md-5 col-lg-4">
                          <div class="post-type post-img ">
                              <a href="#"><img src="${data[post_number].Image}"
                                      class="img-responsive imagecls" alt="image post"  max-width: 500px;></a>
                          </div>
                          <div class="author-info author-info-2">
                              <ul class="list-inline">
  
                                  <li>
                                      <div class="info">
                                          <p>Comments:</p><strong >${commentnumber}</strong>
                                      </div>
                                  </li>
                              </ul>
                          </div>
                      </div>
                      <div class="col-xs-12 col-sm-7 col-md-7 col-lg-8">
                          <div class="caption">
                              <h3 class="md-heading">Caption:</h3>
                              <p> ${data[post_number].Description} </p>
                              <button class="btn btn-default" onClick="showComment(${data[post_number].id})" role="button">Comment</button>
                              <button class="btn btn-default" onClick="AddCommentFunction(${data[post_number].id})" role="button"> Add Comment</button>

                          </div >
                        <div id="comment${data[post_number].id}" style="display:None">
                            
                        </div>
                        <div id="addcomment${data[post_number].id}" style="display:None">
                            <form onsubmit="Submitcomment(event)">
                            <input type="text" name="comment" value="" class="">
                            <input type="hidden" name="post_id" value="${data[post_number].id}">
                                <button  type="submit" >save</button>
                            </form>
                        </div>

                    
                        
                    
                      </div >
                  </div >
              </article >
          </div >`);
                    if (commentnumber == 0) {
                        
                        $('#comment' + data[post_number].id).append(
                            `<p class="fontclass"><strong>No Comment Available</strong></p>`
                        );
                    }
                    else {
                        for (let commentnum = 0; commentnum < commentnumber; commentnum++) {
                            $('#comment' + data[post_number].id).append(
                                `<div>
                                <p class="fontclass">${data[post_number].comments[commentnum].commentor}&nbsp&nbsp:&nbsp&nbsp${data[post_number].comments[commentnum].comment}
                                <button class="btn btn-default" onClick="editCommentFunction(${data[post_number].comments[commentnum].id})" role="button"  >edit</button>
                                </p>
                                </div>
                                <div id="editcomment${data[post_number].comments[commentnum].id}">
                                </div>`

                            );
                            $('#editcomment'+data[post_number].comments[commentnum].id).append(
                                `
                                <form id="editcommentform${data[post_number].comments[commentnum].id}" onsubmit="posteditedbutton(${data[post_number].comments[commentnum].id},event)">
                                <input type="text" name="comment" value="${data[post_number].comments[commentnum].comment}" class="">
                                <button  type="submit" >save</button>
                                
                                </form>`
                            );

                            $('#editcomment'+data[post_number].comments[commentnum].id).hide()
                        }
                    }

                    $('#comment'+data[post_number].id).hide()

                }
            }
            else {
                alert(data['error']);
                
                document.location.href = "/profileRender/"
            }
        },
        error: handleAjaxError
    });
});

function showComment(post_id) {
    $('#comment' + post_id).show();
}


function editCommentFunction(id){
    $('#comment' + id).hide();
    $('#editcomment'+id).show()

}
function posteditedbutton(id,event){
        event.preventDefault();
        var f = event.target;
        var formData = new FormData(f);
        comment_id = id
        formData.append("comment_id",id)
    
        $.ajax({
            url: "/comment/",
            type: "PUT",
            headers: {
                'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
            },
            data: formData,
            processData: false,
            contentType: false,
            tokenFlag: true,
            success: function (data) {
                if(!data['error']){
                    alert(data['success'])
                    $('#editcomment'+id).hide()
                    // location.reload()
                }
                else{
                    alert(data['error'])
                }
            },
            error: handleAjaxError
        });
 
}

function AddCommentFunction(id){
    $("#addcomment"+id).show()   
    // $('#comment' + id).hide();
}
function Submitcomment(event){
    event.preventDefault();
        var f = event.target;
        var formData = new FormData(f);
        $.ajax({
            url: "/comment/",
            type: "POST",
            headers: {
                'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
            },
            data: formData,
            processData: false,
            contentType: false,
            tokenFlag: true,
            success: function (data) {
                if(!data['error']){
                    alert(data['success'])
                }
                else{
                    alert(data['error'])
                }
            
    
            },
            error: handleAjaxError
        });
 
}

function handleAjaxError(rs, e) {
   
    if (rs.status == 401) {
        if (this.tokenFlag) {
            this.tokenFlag = false;
            if (obtainAccessTokenWithRefreshToken()) {
                this.headers["Authorization"] = `Bearer ${window.localStorage.getItem('accessToken')}`
                $.ajax(this);  // calling API endpoint again with new access token
            }
        }
    } else {
        alert("unknown error")
        console.error(rs.responseText);
    }
}

function obtainAccessTokenWithRefreshToken() {
   
    let flag = true;
    let formData = new FormData();
    formData.append('refresh', window.localStorage.getItem('refreshToken'));
    $.ajax({
        url: '/token/refresh/',
        type: "POST",
        data: formData,
        async: false,
        cache: false,
        processData: false,
        contentType: false,
        success: function (data) {
            window.localStorage.setItem('accessToken', data['access']);
        },
        error: function (rs, e) {
            if (rs.status == 401) {
                flag = false;
                alert("Session timeout please login again...")
                window.location.href = "/";
            } else {
                console.error(rs.responseText);
            }
        }
    }); 
    return flag
}