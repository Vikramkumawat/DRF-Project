$('.body').ready(function (event) {
    $.ajax({
        url: '/profilecard/',
        headers: {
          'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
        },
        type: "GET",
        tokenFlag: true,
        success: function (data) {
          if (!data['error']) {
            for (let profile_number = 0; profile_number < data.length; profile_number++) {
                $(".dataclass").append(

                    
                    `
                    <a onclick="chatwithhim(${data[profile_number].id},'${data[profile_number].user}')">
                        <div class="profile">
                            <ul>
                                <div class="imgandname">
                                    <div>
                                        <img src="${data[profile_number].display_picture}" alt="profile pic" width="75px" class="profileimg">
                    
                                    </div>
                                    <div class="namebio">
                                        <h3 class="name ">${data[profile_number].user}</h3>
                                        <p class="bio">${data[profile_number].Bio}.</p>
                                    </div>
                                </div>
                            </ul>
                    
                        </div>
                    
                    </a>
                    <div class="chatclass${data[profile_number].id} mychat ">
                    <div class="chatsclass${data[profile_number].id} ">

                    </div>

                    </div>
                    `
                )
                $(".chatclass"+data[profile_number].id).hide();
            }
        }}

    });});

function chatwithhim(id, reciever){
    $(".chatclass"+id).show();
    $.ajax({
        url: '/conversation/?reciever_id='+id,
        headers: {
          'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
        },
        type: "GET",
        tokenFlag: true,
        success: function (data) {
            for(let msgnum=0;msgnum<data.length;msgnum++){
                
                if (data[msgnum].reciever == reciever){

                    $(".chatsclass"+id).append(
                        `<div class="dropdown msgclass" id="msgid${data[msgnum].id}" >
                        <div>
                        <p  ><span align="left">${data[msgnum].messege}</span></p></div>
                        <div class="dropdown-content">
                            <a onclick="deleteforme(${data[msgnum].id})">Delete for me</a>
                            <a onclick="deleteforeveryone(${data[msgnum].id})">Delete for everyone</a>
                        </div>
                        </div><br>
                        `
                    )
                }
                else{
                    $(".chatsclass"+id).append(
                        `<div class=" msgclass">
                        <p align="right" ><span>${data[msgnum].messege}</span></p>
                        </div>
                        `
                    )
                }

            }
            $(".chatclass"+id).append(
                `
                <div class="msgclass">
                <form onsubmit="sendmsg(${id},event)">
            <input type="text" name="messege" placeholder="type here" value="" size="80" height="100%">
            <input type="hidden" name="reciever_id"  value="${id}" >
            <button type="submit" class="butonclass"> send</button>
            </form> </div>
                `
            )

        }
    });
}

function sendmsg(id,event){
    
    event.preventDefault();
    var f = event.target;
    var fdata = new FormData(f);

    $.ajax({
        url: "/conversation/",
        type: "POST",
        data: fdata,
        headers: {
            'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
        },
        
        data: fdata,
        processData: false,
        contentType: false,
        tokenFlag: true,
        success: function (data) {

            $(".chatsclass"+id).append(
                `<div class="msgclass">
                <p align="left" ><span>${data['success'].messege}</span></p>
                </div>
                `
            )
        }
    });
}

function deleteforme(id){

    $.ajax({
        url: "/conversation/"+"?id="+id,
        type: "PUT",
        headers: {
            'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
        },
        
        processData: false,
        contentType: false,
        tokenFlag: true,
        success: function (data) {
            $("#msgid"+id).hide()
        }
    });
}

function deleteforeveryone(id){
    $.ajax({
        url: "/conversation/"+"?id="+id,
        type: "DELETE",
        headers: {
            'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
        },
        
        processData: false,
        contentType: false,
        tokenFlag: true,
        success: function (data) {
            $("#msgid"+id).hide()

        }
    });
}

