$('#my_form').submit(function (event) {

    event.preventDefault();
    var f = event.target;
    var fdata = new FormData(f);

    $.ajax({
        url: "/createpost/",
        type: "POST",
        data: fdata,
        headers: {
            'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
        },
        
        data: fdata,
        processData: false,
        contentType: false,
        tokenFlag: true,
        success: function (data) {
            alert(data['success'])
            document.location.href = "/profileRender/"

        },
        error: handleAjaxError
    });
});


function handleAjaxError(rs, e) {
   
    if (rs.status == 401) {
        if (this.tokenFlag) {
            this.tokenFlag = false;
            if (obtainAccessTokenWithRefreshToken()) {
                this.headers["Authorization"] = `Bearer ${window.localStorage.getItem('accessToken')}`
                $.ajax(this);  // calling API endpoint again with new access token
            }
        }
    } else {
        console.error(rs.responseText);
    }
}

function obtainAccessTokenWithRefreshToken() {
   
    let flag = true;
    let formData = new FormData();
    formData.append('refresh', window.localStorage.getItem('refreshToken'));
    $.ajax({
        url: '/token/refresh/',
        type: "POST",
        data: formData,
        async: false,
        cache: false,
        processData: false,
        contentType: false,
        success: function (data) {
            window.localStorage.setItem('accessToken', data['access']);
        },
        error: function (rs, e) {
            if (rs.status == 401) {
                flag = false;
                alert("Session timeout please login again...")
                window.location.href = "/";
            } else {
                console.error(rs.responseText);
            }
        }
    }); 
    return flag
}