$('#user_profile').ready(function (event) {
  $.ajax({
    url: '/friendrequest/',
    headers: {
      'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
    },
    type: "GET",
    tokenFlag: true,
    success: function (data) {
      if (!data['error']) {
        for (let profile_number = 0; profile_number < data.length; profile_number++) {
          $('.profile_container').append(

            `<div class="col-md-4 my_class">
                  <div class="d-flex align-items-center my_class2">
                    <div class="image">
                      <img id="user_picture" src="${data[profile_number]['display_picture']}" class="rounded" width="155" style="height:155px" />
                    </div>
            
                    <div class="ml-3 w-100">
                      <h4 class="mb-0 mt-0" id="user_name">&#160;&#160;&#160;${data[profile_number].sender}</h4>
            
                      <div class=" p-2 mt-2 bg-primary d-flex justify-content-between rounded text-white stats">
            
                        <div class="d-flex flex-column">
                          <span class="followers">Followers</span>
                          <span class="number2" id="followers${data[profile_number].sender}" >${data[profile_number].followers}</span>
                        </div>
            
                        <div class="d-flex flex-column">
                          <span class="rating">Following</span>
                          <p class="number3" >${data[profile_number].following}</p>
                        </div>
                        <div class="d-flex flex-column">
                          <span class="rating">Friends</span>
                          <span class="number3">${data[profile_number].friends}</span>
                        </div>
                      </div>
            
                      <div class="button mt-2 d-flex flex-row align-items-center">
                        <button class="btn btn-sm btn-outline-primary w-100" onClick="AcceptFunction('${data[profile_number].sender}')">
                          Accept
                        </button>
                        <button class="btn btn-sm btn-primary w-100 ml-2" id="followersbutton${data[profile_number].sender}" onClick="deleteFunction('${data[profile_number].sender}')">
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                `);
        }
      }
      else {
        alert(data['error']);
        document.location.href = "/profileRender/"
      }
    },
    error: function (data) {
      document.location.href = "/profileRender/"
      alert(data['error'])
    }
  });
});

function AcceptFunction(sender) {

  var sender = sender
  $.ajax({
    url: "/accept_delete/add/",
    type: "POST",
    data: { "sender": sender },
    headers: {
      'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
    },
    tokenFlag: true,
    success: function (data) {
      if (!data['error']) {
        location.reload()
      }
      else
        alert(data['error'])

    },
    error: function (data) {
      alert(data['error'])
    }
  });
}

function deleteFunction(sender) {
  var sender = sender
  $.ajax({
    url: "/accept_delete/remove/",
    type: "POST",
    data: { "sender": sender },
    headers: {
      'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
    },
    tokenFlag: true,
    success: function (data) {
      if (!data['error']) {
        location.reload()
      }

      else
        alert(data['error'])

    },
    error: function (data) {
      alert(data['error'])
    }
  });


}

