$('#user_profile').ready(function (event) {
  $.ajax({
    url: '/profilecard/',
    headers: {
      'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
    },
    type: "GET",
    tokenFlag: true,
    success: function (data) {
      if (!data['error']) {
        for (let profile_number = 0; profile_number < data.length; profile_number++) {
          $('.profile_container').append(

            `<div class="col-md-4 my_class">
                    <div class="d-flex align-items-center my_class2">
                      <div class="image">
                        <img id="user_picture" src="${data[profile_number]['display_picture']}" class="rounded" width="155" style="height:155px" />
                      </div>
              
                      <div class="ml-3 w-100">
                        <h4 class="mb-0 mt-0" id="user_name">&#160;&#160;&#160;${data[profile_number]['user']}</h4>
              
                        <div class=" p-2 mt-2 bg-primary d-flex justify-content-between rounded text-white stats">
              
                          <div class="d-flex flex-column">
                            <span class="followers">Followers</span>
                            <span class="number2" id="followers${data[profile_number]['id']}" >${data[profile_number]['followers'].length}</span>
                          </div>
              
                          <div class="d-flex flex-column">
                            <span class="rating">Following</span>
                            <p class="number3" >${data[profile_number]['following'].length}</p>
                          </div>
                          <div class="d-flex flex-column">
                            <span class="rating">Friends</span>
                            <span class="number3">${data[profile_number]['friends'].length}</span>
                          </div>
                        </div>
              
                        <div class="button mt-2 d-flex flex-row align-items-center">
                          <button class="btn btn-sm btn-outline-primary w-100" id='sendrequest${data[profile_number].id}' onClick="RequestFunction(${data[profile_number].id})">
                            Send Request
                          </button>
                          <button class="btn btn-sm btn-outline-primary w-100" id='removefrnd${data[profile_number].id}' onClick="removeFriendFunction(${data[profile_number].id})">
                            Remove frnd
                          </button>
                          <button class="btn btn-sm btn-outline-primary w-100" id='cancelrequest${data[profile_number].id}' onClick="CancelRequestFunction(${data[profile_number].id})">
                            cancel
                          </button>
                          <button class="btn btn-sm btn-primary w-100 ml-2" id="followersbutton${data[profile_number].id}" onClick="FollowFunction(${data[profile_number].id})">
                            Follow
                          </button>

                          <button class="btn btn-sm btn-primary w-100 ml-2" id="unfollowbutton${data[profile_number].id}" onClick="UnfollowFunction(${data[profile_number].id})">
                            following
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  `);
          for (let follower = 0; follower < data[profile_number].followers.length; follower++) {
            if (document.getElementById('userloggedin').value == data[profile_number].followers[follower].user) {
              $('#unfollowbutton' + data[profile_number].id).show()
              $('#followersbutton' + data[profile_number].id).hide()
              $('#removefrnd' + data[profile_number].id).hide()

              break;

            }
            else {
              $('#followersbutton' + data[profile_number].id).show()
              $('#unfollowbutton' + data[profile_number].id).hide()
              $('#removefrnd' + data[profile_number].id).hide()

            }
          }
          if (data[profile_number].friends.length == 0) {
            $('#cancelrequest' + data[profile_number].id).hide()
            $('#sendrequest' + data[profile_number].id).show()
            $('#removefrnd' + data[profile_number].id).hide()

          }
          else {
            for (let friend = 0; friend < data[profile_number].friends.length; friend++) {
              if (document.getElementById('userloggedin').value == data[profile_number].friends[friend].user) {
                $('#removefrnd' + data[profile_number].id).show()
                $('#cancelrequest' + data[profile_number].id).hide()
                $('#sendrequest' + data[profile_number].id).hide()
                break;
              }
              else {
                if (data[profile_number].friendrequests.length == 0) {
                  $('#cancelrequest' + data[profile_number].id).hide()
                  $('#sendrequest' + data[profile_number].id).show()
                  $('#removefrnd' + data[profile_number].id).hide()

                }
                else {

                  for (let frequest = 0; frequest < data[profile_number].friendrequests.length; frequest++) {
                    if (document.getElementById('userloggedin').value == data[profile_number].friendrequests[frequest].sender) {

                      $('#cancelrequest' + data[profile_number].id).show()
                      $('#sendrequest' + data[profile_number].id).hide()
                      $('#removefrnd' + data[profile_number].id).hide()

                      break;
                    }
                    else {

                      $('#cancelrequest' + data[profile_number].id).hide()
                      $('#sendrequest' + data[profile_number].id).show()
                      $('#removefrnd' + data[profile_number].id).hide()

                    }
                  }
                }
              }
            }
          }
        }
      }
      else {
        alert(data['error']);
      }
    },
    error: handleAjaxError
  });
});



function RequestFunction(id) {
  var id = id
  $.ajax({
    url: "/friendrequest/",
    type: "POST",
    data: { "id": id },
    headers: {
      'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
    },
    tokenFlag: true,
    success: function (data) {
      if (!data['error']) {
        $('#cancelrequest' + id).show()
        $('#sendrequest' + id).hide()
        $('#removefrnd' + id).hide()
        // alert(data['success'])
      }
      else
        alert(data['error'])

    },
    error: handleAjaxError
  });


}

function CancelRequestFunction(id) {
  var reciever_id = id
  $.ajax({
    url: "/friendrequest/",
    type: "DELETE",
    data: { "reciever_id": reciever_id },
    headers: {
      'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
    },
    tokenFlag: true,
    success: function (data) {
      if (!data['error']) {
        $('#cancelrequest' + id).hide()
        $('#sendrequest' + id).show()
        $('#removefrnd' + id).hide()
        // alert(data['success'])
      }
      else
        alert(data['error'])

    },
    error: handleAjaxError
  });
}

function FollowFunction(id) {

  var id = id
  $.ajax({
    url: "/follow-user/",
    type: "POST",
    data: { "id": id },
    headers: {
      'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
    },
    tokenFlag: true,
    success: function (data) {

      if (!data['error']) {
        $('#unfollowbutton' + id).show()
        $('#followersbutton' + id).hide()
        // alert(data['success'])
      }
      else
        alert(data['error'])

    },
    error: handleAjaxError
  });
}


function UnfollowFunction(id) {
  var id = id
  $.ajax({
    url: "/unfollow/",
    type: "POST",
    data: { "id": id },
    headers: {
      'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
    },
    tokenFlag: true,
    success: function (data) {
      if (!data['error']) {
        $('#followersbutton' + id).show()
        $('#unfollowbutton' + id).hide()
        // alert(data['success'])
      }
      else {
        alert(data['error'])
      }

    },
    error: handleAjaxError
  });

}

function removeFriendFunction(id) {
  var id = id
  $.ajax({
    url: "/removefriend/",
    type: "POST",
    data: { "id": id },
    headers: {
      'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
    },
    tokenFlag: true,
    success: function (data) {

      $('#cancelrequest' + id).hide()
      $('#sendrequest' + id).show()
      $('#removefrnd' + id).hide()

      // alert(data['success'])

    },
    error: handleAjaxError
  });
}

function handleAjaxError(rs, e) {
   
  if (rs.status == 401) {
      if (this.tokenFlag) {
          this.tokenFlag = false;
          if (obtainAccessTokenWithRefreshToken()) {
              this.headers["Authorization"] = `Bearer ${window.localStorage.getItem('accessToken')}`
              $.ajax(this);  // calling API endpoint again with new access token
          }
      }
  } else {
      console.error(rs.responseText);
  }
}

function obtainAccessTokenWithRefreshToken() {
 
  let flag = true;
  let formData = new FormData();
  formData.append('refresh', window.localStorage.getItem('refreshToken'));
  $.ajax({
      url: '/token/refresh/',
      type: "POST",
      data: formData,
      async: false,
      cache: false,
      processData: false,
      contentType: false,
      success: function (data) {
          window.localStorage.setItem('accessToken', data['access']);
      },
      error: function (rs, e) {
          if (rs.status == 401) {
              flag = false;
              alert("Session timeout please login again...")
              window.location.href = "/";
          } else {
              console.error(rs.responseText);
          }
      }
  }); 
  return flag
}