$('#my_form').submit(function (event) {
    event.preventDefault();
    var formData = $('#my_form').serializeArray();
    formData = JSON.parse(JSON.stringify(formData))
    $.ajax({
      url: "/login/",
      type: "POST",
      data: formData,
      success: function (data) {
        if (!data['error']) {
          window.localStorage.setItem('refreshToken', data['refresh']);
          window.localStorage.setItem('accessToken', data['access']);
          document.location.href = "/profileRender/"
        }
        else {
          alert(data['error'])
        }

      },
      error: function (data) {
        console.log(data)
        alert(data['error'])
      }
    });
  });


  $('#my_form_register').submit(function (event) {
    event.preventDefault();
    var formData = $('#my_form_register').serializeArray();
    formData = JSON.parse(JSON.stringify(formData))
    console.log(formData)
    $.ajax({
      url: "/register/",
      type: "POST",
      data: formData,

      success: function (data) {
        console.log(data)
        alert('Register success');
        document.location.href = "/"
      },
      error: function (data) {
        alert(data['error']);
      }
    });
  });

function  openSocial(){
  document.location.href ="/social/sociallogin/"
}
