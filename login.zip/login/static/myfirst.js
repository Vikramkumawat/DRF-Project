function myFunction() {
    alert("Hello from a static file!");
  }