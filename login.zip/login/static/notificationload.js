$('#notificationtempid').ready(function (event) {
    $.ajax({
      url: '/checknotification/',
      headers: {
        'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
      },
      type: "GET",
      tokenFlag: true,
      success: function (data) {
          if (!data['error']) {
          for(let notification_number = 0;notification_number<data.length;notification_number++){
              $('.notificationclass').append(

            `<center><div class="w-50 p-3 notify mt-5 card ">
            <div  >
              <svg class=" rounded mr-2" width="20" height="20" xmlns="http://www.w3.org/2000/svg"
                preserveAspectRatio="xMidYMid slice" focusable="false" role="img">
                <rect fill="#007aff" width="100%" height="100%" /></svg>
              <strong class="mr-auto">Notification</strong>
              <small>${ data[notification_number].notification_time.slice(0,16)}</small>
              <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" onClick="Delete(${data[notification_number].id})" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="toast-body">
              ${data[notification_number].details}
            </div>
          </div></center><br>
            
            `);
          }
        }

        else {
          alert(data['error']);
          document.location.href = "/profileRender/"
        }
      },
      error: handleAjaxError
    });
  }); 

  function Delete(id){
    var id = id
    $.ajax({
        url: "/checknotification/",
        type: "DELETE",
        data:{"id":id},
      headers: {
          'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
        },
        tokenFlag: true,
        success: function (data) {
          if (!data['error']){
              location.reload()
          }
          else
              alert(data['error'])

        },
        error: handleAjaxError
      });
  }

  function handleAjaxError(rs, e) {
   
    if (rs.status == 401) {
        if (this.tokenFlag) {
            this.tokenFlag = false;
            if (obtainAccessTokenWithRefreshToken()) {
                this.headers["Authorization"] = `Bearer ${window.localStorage.getItem('accessToken')}`
                $.ajax(this);  // calling API endpoint again with new access token
            }
        }
    } else {
        console.error(rs.responseText);
    }
}

function obtainAccessTokenWithRefreshToken() {
   
    let flag = true;
    let formData = new FormData();
    formData.append('refresh', window.localStorage.getItem('refreshToken'));
    $.ajax({
        url: '/token/refresh/',
        type: "POST",
        data: formData,
        async: false,
        cache: false,
        processData: false,
        contentType: false,
        success: function (data) {
            window.localStorage.setItem('accessToken', data['access']);
        },
        error: function (rs, e) {
            if (rs.status == 401) {
                flag = false;
                alert("Session timeout please login again...")
                window.location.href = "/";
            } else {
                console.error(rs.responseText);
            }
        }
    }); 
    return flag
}