$('#my_form').submit(function (event) {

    event.preventDefault();
    var f = event.target;
    var fdata = new FormData(f);

    $.ajax({
        url: "/profile/",
        type: "POST",
        data: fdata,
        headers: {
            'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
        },
        data: fdata,
        processData: false,
        contentType: false,
        tokenFlag: true,
        success: function (data) {
            if(!data['error']){
            document.location.href = "/profileRender/"}
            else{
                alert(data['error'])
            }

        },
        error: function (data) {
            alert(data['error'])
        }
    });
});
