$('#my_profile').ready(function (event) {
    $.ajax({
        url: '/profile/',
        headers: {
            'Authorization': `Bearer ${window.localStorage.getItem('accessToken')}`
        },
        type: "GET",
        tokenFlag: true,
        success: function (data) {
            if (!data['error']) {

                document.getElementById("user").innerHTML = data['user'];
                document.getElementById("Bio").innerHTML = data['Bio'];
                document.getElementById("profilepic").src = data['display_picture'];
            }
            else {
                window.location.href = "/onboardrender/"
                alert(data['error']);

            }


        },
        error: handleAjaxError
    });
});

function handleAjaxError(rs, e) {
   
    if (rs.status == 401) {
        if (this.tokenFlag) {
            this.tokenFlag = false;
            if (obtainAccessTokenWithRefreshToken()) {
                this.headers["Authorization"] = `Bearer ${window.localStorage.getItem('accessToken')}`
                $.ajax(this);  // calling API endpoint again with new access token
            }
        }
    } else {
        console.error(rs.responseText);
    }
  }
  
  function obtainAccessTokenWithRefreshToken() {
   
    let flag = true;
    let formData = new FormData();
    formData.append('refresh', window.localStorage.getItem('refreshToken'));
    $.ajax({
        url: '/token/refresh/',
        type: "POST",
        data: formData,
        async: false,
        cache: false,
        processData: false,
        contentType: false,
        success: function (data) {
            window.localStorage.setItem('accessToken', data['access']);
        },
        error: function (rs, e) {
            if (rs.status == 401) {
                flag = false;
                alert("Session timeout please login again...")
                window.location.href = "/";
            } else {
                console.error(rs.responseText);
            }
        }
    }); 
    return flag
  }


  $("#logout-form").submit(function (event) {
    event.preventDefault();
    window.localStorage.removeItem('refreshToken');
    window.localStorage.removeItem('accessToken');
    window.location.href = "/";
});